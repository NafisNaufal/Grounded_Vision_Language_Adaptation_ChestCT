"""
make_architecture.py
--------------------
Generates paper/figures/architecture.pdf using matplotlib.
Run:  python paper/figures/make_architecture.py
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

C_BLUE   = "#2962B4"
C_GREEN  = "#1A7A1A"
C_ORANGE = "#A84A10"
C_PURPLE = "#6E2E90"
C_GRAY   = "#555555"

BG_BLUE   = "#E8F0FB"
BG_GREEN  = "#E8F8E8"
BG_ORANGE = "#FBF2E4"
BG_PURPLE = "#F4ECF9"
BG_LIGHT  = "#F3F7FF"

fig, ax = plt.subplots(figsize=(10, 9))
ax.set_xlim(0, 10)
ax.set_ylim(0, 9)
ax.axis("off")


# ── Helpers ──────────────────────────────────────────────────────────────────

def rbox(cx, cy, w, h, label, sublabel="", fc=BG_LIGHT, ec=C_BLUE,
         lw=1.3, fontsize=8.5, bold=False, linestyle="-", z=3):
    rect = FancyBboxPatch(
        (cx - w/2, cy - h/2), w, h,
        boxstyle="round,pad=0.07", fc=fc, ec=ec, lw=lw,
        linestyle=linestyle, zorder=z,
    )
    ax.add_patch(rect)
    fw = "bold" if bold else "normal"
    if sublabel:
        ax.text(cx, cy + 0.14, label, ha="center", va="center",
                fontsize=fontsize, fontweight=fw, color=ec, zorder=z+1)
        ax.text(cx, cy - 0.18, sublabel, ha="center", va="center",
                fontsize=fontsize - 1.5, color=C_GRAY, zorder=z+1)
    else:
        ax.text(cx, cy, label, ha="center", va="center",
                fontsize=fontsize, fontweight=fw, color=ec, zorder=z+1)


def varr(x, y0, y1, color, lw=1.5, ls="solid"):
    ax.annotate("", xy=(x, y1), xytext=(x, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw,
                                mutation_scale=10, linestyle=ls,
                                connectionstyle="arc3,rad=0.0"), zorder=6)


def panel(cx, cy, w, h, fc, ec):
    rect = FancyBboxPatch(
        (cx - w/2, cy - h/2), w, h,
        boxstyle="round,pad=0.12", fc=fc, ec=ec, lw=1.2,
        linestyle="--", alpha=0.45, zorder=1,
    )
    ax.add_patch(rect)


# ── Vertical layout  ─────────────────────────────────────────────────────────
#  8.55  figure title
#  7.60  input row
#  6.30  VILA-M3  (height 1.0 → bottom 5.80)
#  5.20  T-junction bus  (gap of 0.60 below VLM gives room for labels)
#        left arm label  "→ VISTA3D(lung tumor)"  at y=5.35 above bus
#        right arm label "retrieval query"         at y=5.35 above bus
#  4.85  panel titles  (above panel top edge at 4.70)
#  3.80  expert nodes
#  2.55  output nodes
#  1.35  LIDC-IDRI  (inside green panel whose bottom is 0.95)

Y_VLM    = 6.30
Y_BUS    = 5.20    # horizontal T-junction
Y_PTOP   = 4.70    # top edge of panels
Y_PTITLE = 4.83    # panel title  (just above panel top)
Y_EXPERT = 3.80
Y_OUT    = 2.55
Y_LIDC   = 1.35

# ── Background panels ─────────────────────────────────────────────────────────
# Detection: cy = midpoint of [0.95, 4.70] = 2.825  h = 3.75
DET_CY = (Y_PTOP + 0.95) / 2      # 2.825
DET_H  = Y_PTOP - 0.95             # 3.75
panel(2.55, DET_CY, 3.80, DET_H, BG_GREEN,  C_GREEN)

RET_CY = (Y_PTOP + 1.50) / 2      # 3.10
RET_H  = Y_PTOP - 1.50             # 3.20
panel(7.45, RET_CY, 3.80, RET_H, BG_ORANGE, C_ORANGE)

# Panel titles: clearly above panel top
ax.text(2.55, Y_PTITLE, "Detection Branch", ha="center", va="bottom",
        fontsize=9, fontweight="bold", color=C_GREEN, zorder=7)
ax.text(7.45, Y_PTITLE, "Retrieval Branch",  ha="center", va="bottom",
        fontsize=9, fontweight="bold", color=C_ORANGE, zorder=7)

# ── Input nodes ───────────────────────────────────────────────────────────────
rbox(3.0, 7.60, 2.55, 0.72, "Key CT Slices", "(16 axial)",
     fc=BG_LIGHT, ec=C_BLUE, fontsize=8.5)
rbox(7.0, 7.60, 2.55, 0.72, "Clinical Query", "(natural language)",
     fc=BG_LIGHT, ec=C_BLUE, fontsize=8.5)

# ── CT-RATE side-box ──────────────────────────────────────────────────────────
rbox(0.90, Y_VLM, 1.55, 0.68, "CT-RATE", "(fine-tune)",
     fc=BG_PURPLE, ec=C_PURPLE, fontsize=7.5, linestyle="--")

# ── VILA-M3 box (two-line: name + italic "intent classification") ─────────────
rect = FancyBboxPatch(
    (5.0 - 1.70, Y_VLM - 0.52), 3.40, 1.04,
    boxstyle="round,pad=0.07", fc=BG_BLUE, ec=C_BLUE, lw=2.1, zorder=3,
)
ax.add_patch(rect)
ax.text(5.0, Y_VLM + 0.18, "VILA-M3", ha="center", va="center",
        fontsize=11, fontweight="bold", color=C_BLUE, zorder=4)
ax.text(5.0, Y_VLM - 0.13, "(LoRA adapted)", ha="center", va="center",
        fontsize=8.5, color=C_GRAY, zorder=4)
# intent classification as a subtle footer inside the box
ax.text(5.0, Y_VLM - 0.40, "intent classification  ▾",
        ha="center", va="center",
        fontsize=6.5, color=C_BLUE, style="italic", zorder=4)

# ── Arrows: inputs → VILA-M3 ─────────────────────────────────────────────────
ax.annotate("", xy=(4.1, Y_VLM + 0.52), xytext=(3.0, 7.24),
            arrowprops=dict(arrowstyle="-|>", color=C_BLUE, lw=1.5,
                            mutation_scale=10,
                            connectionstyle="arc3,rad=0.0"), zorder=6)
ax.annotate("", xy=(5.9, Y_VLM + 0.52), xytext=(7.0, 7.24),
            arrowprops=dict(arrowstyle="-|>", color=C_BLUE, lw=1.5,
                            mutation_scale=10,
                            connectionstyle="arc3,rad=0.0"), zorder=6)

# ── LoRA arrow ────────────────────────────────────────────────────────────────
ax.annotate("", xy=(3.30, Y_VLM), xytext=(1.68, Y_VLM),
            arrowprops=dict(arrowstyle="-|>", color=C_PURPLE, lw=1.3,
                            mutation_scale=10,
                            connectionstyle="arc3,rad=0.0"), zorder=6)
ax.text(2.49, Y_VLM + 0.15, "LoRA fine-tuning", ha="center", va="bottom",
        fontsize=6.5, color=C_PURPLE, style="italic", zorder=7)

# ── T-junction elbow routing ──────────────────────────────────────────────────
VLM_BOTTOM = Y_VLM - 0.52    # 5.78

# Vertical stem from VLM bottom to bus
ax.plot([5.0, 5.0], [VLM_BOTTOM, Y_BUS],
        color=C_GRAY, lw=1.4, zorder=6, solid_capstyle="round")

# Horizontal bus: left arm to x=2.55, right arm to x=7.45
ax.plot([2.55, 7.45], [Y_BUS, Y_BUS],
        color=C_GRAY, lw=1.4, zorder=6, solid_capstyle="round")

# Junction dot
ax.plot(5.0, Y_BUS, "o", color=C_GRAY, markersize=5, zorder=7)

# Left vertical arrow: bus → VISTA3D top
ax.annotate("", xy=(2.55, Y_EXPERT + 0.38), xytext=(2.55, Y_BUS),
            arrowprops=dict(arrowstyle="-|>", color=C_GREEN, lw=1.6,
                            mutation_scale=10,
                            connectionstyle="arc3,rad=0.0"), zorder=6)

# Right vertical arrow: bus → FAISS top
ax.annotate("", xy=(7.45, Y_EXPERT + 0.38), xytext=(7.45, Y_BUS),
            arrowprops=dict(arrowstyle="-|>", color=C_ORANGE, lw=1.6,
                            mutation_scale=10,
                            connectionstyle="arc3,rad=0.0"), zorder=6)

# Route labels — on horizontal arms, above bus line, well separated
ax.text(3.55, Y_BUS + 0.10, "<VISTA3D(lung tumor)>",
        ha="center", va="bottom", fontsize=6.5, color=C_GREEN,
        style="italic", zorder=8,
        bbox=dict(fc="white", ec="none", alpha=0.9, pad=1.5))

ax.text(6.45, Y_BUS + 0.10, "retrieval query",
        ha="center", va="bottom", fontsize=6.5, color=C_ORANGE,
        style="italic", zorder=8,
        bbox=dict(fc="white", ec="none", alpha=0.9, pad=1.5))

# ── Expert nodes ──────────────────────────────────────────────────────────────
rbox(2.55, Y_EXPERT, 2.95, 0.76, "VISTA3D", "(lung tumor  ·  label 23)",
     fc=BG_GREEN, ec=C_GREEN, fontsize=8.5)
rbox(7.45, Y_EXPERT, 2.95, 0.76, "FAISS Index", "(CT-RATE embeddings)",
     fc=BG_ORANGE, ec=C_ORANGE, fontsize=8.5)

# ── Expert → output arrows ────────────────────────────────────────────────────
varr(2.55, Y_EXPERT - 0.38, Y_OUT + 0.38, C_GREEN)
varr(7.45, Y_EXPERT - 0.38, Y_OUT + 0.38, C_ORANGE)

# ── Output nodes ──────────────────────────────────────────────────────────────
rbox(2.55, Y_OUT, 2.95, 0.76, "Binary Mask", "Dice (DSC)  ·  IoU",
     fc="#EEF9EE", ec=C_GREEN, fontsize=8.5)
rbox(7.45, Y_OUT, 2.95, 0.76, "Top-K Cases", "Recall@{1, 5, 10}",
     fc="#FDF6EC", ec=C_ORANGE, fontsize=8.5)

# ── LIDC-IDRI ground-truth (inside green panel) ───────────────────────────────
rbox(2.55, Y_LIDC, 2.75, 0.62, "LIDC-IDRI  ·  ground truth",
     fc="white", ec=C_GRAY, fontsize=7.2, linestyle="--")
varr(2.55, Y_OUT - 0.38, Y_LIDC + 0.31, C_GRAY, lw=1.1, ls="dashed")
ax.text(3.08, (Y_OUT - 0.38 + Y_LIDC + 0.31) / 2,
        "zero-shot eval", ha="left", va="center",
        fontsize=6.2, color=C_GRAY, style="italic", zorder=7)

# ── Figure title ──────────────────────────────────────────────────────────────
ax.text(5.0, 8.60, "Proposed Framework: VILA-M3 Expert-Routed Adaptation",
        ha="center", va="center", fontsize=12, fontweight="bold", color="#1A1A2E")

plt.tight_layout(pad=0.1)
plt.savefig("architecture.pdf", bbox_inches="tight", dpi=200, format="pdf")
print("Saved architecture.pdf")
